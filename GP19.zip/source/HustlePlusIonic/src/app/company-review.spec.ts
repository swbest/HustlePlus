import { CompanyReview } from './company-review';

describe('CompanyReview', () => {
  it('should create an instance', () => {
    expect(new CompanyReview()).toBeTruthy();
  });
});
