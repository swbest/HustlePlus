import { Component, OnInit } from '@angular/core';



@Component({
  selector: 'app-access-right-error',
  templateUrl: './access-right-error.page.html',
  styleUrls: ['./access-right-error.page.scss'],
})

export class AccessRightErrorPage implements OnInit
{
	constructor()
	{		
	}



	ngOnInit()
	{
	}
}
