export enum AccessRightEnum 
{
	STUDENT
}
