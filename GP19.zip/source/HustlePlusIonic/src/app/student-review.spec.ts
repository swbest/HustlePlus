import { StudentReview } from './student-review';

describe('StudentReview', () => {
  it('should create an instance', () => {
    expect(new StudentReview()).toBeTruthy();
  });
});
