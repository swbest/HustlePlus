/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws.restful.model;

/**
 *
 * @author dtjldamien
 */
public class CreateNewTeamRsp {

    private Long newTeamId;

    public CreateNewTeamRsp() {
    }

    public CreateNewTeamRsp(Long newTeamId) {
        this.newTeamId = newTeamId;
    }

    public Long getNewTeamId() {
        return newTeamId;
    }

    public void setNewTeamId(Long newTeamId) {
        this.newTeamId = newTeamId;
    }

}
