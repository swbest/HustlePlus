/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package web.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * Web application lifecycle listener.
 *
 * @author amand
 */
public class WebApplicationListener implements ServletContextListener, HttpSessionListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        sce.getServletContext().setAttribute("visitorCounter", 0);
	System.out.println("******** contextInitialised: " + sce.getServletContext().getAttribute("visitorCounter"));
}


    @Override
    public void contextDestroyed(ServletContextEvent sce) {
    }

    @Override
    public void sessionCreated(HttpSessionEvent se) {
        se.getSession().setAttribute("isLogin", false);
        se.getSession().getServletContext().setAttribute("visitor counter", ((int)se.getSession().getServletContext().getAttribute("visitorCounter")) + 1);
	System.out.println("******** sessionCreated: " + se.getSession().getServletContext().getAttribute("visitorCounter"));
}


    @Override
    public void sessionDestroyed(HttpSessionEvent se) {
    }
}
