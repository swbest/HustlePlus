import { Milestone } from './milestone';

describe('Milestone', () => {
  it('should create an instance', () => {
    expect(new Milestone()).toBeTruthy();
  });
});
