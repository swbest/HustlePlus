export enum Colors {
    GREY = "#E0E0E0",
    GREEN = "#76FF03",
    YELLOW = "FFCA28",
    RED = "#DD2C00"
}
